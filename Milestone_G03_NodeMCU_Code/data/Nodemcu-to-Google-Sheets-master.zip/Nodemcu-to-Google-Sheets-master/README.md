# Nodemcu-to-Google-Sheets

Full tutorial : https://bit.ly/2ZQulYc

Trigger GoogleSheets Library is self written by me and free to use.

How to use Trigger GoogleSheets Library: 

1. Initialization: 
   Enter variables from Script into Column_name_in_Sheets
   Enter Gas ID
   Enter No of Parameters to be sent
   
   Call Google_Sheets_Init();
   
2. To Send Data call Data_to_Sheets();
    
